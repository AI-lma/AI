from docx import Document
from datetime import datetime
import os


def generate_docx(title, content, client_name=""):
    doc = Document()

    # 标题
    doc.add_heading(title, level=0)

    # 基本信息
    if client_name:
        doc.add_paragraph(f"委托方：{client_name}")
    doc.add_paragraph(f"出具日期：{datetime.now().strftime('%Y年%m月%d日')}")
    doc.add_paragraph("─" * 30)

    # 正文内容
    for line in content.split("\n"):
        if line.strip() == "":
            continue
        # 识别标题行（一、二、三 或 【xxx】）
        if line.strip()[0] in "一二三四五六七八九十" and "、" in line[:3]:
            doc.add_heading(line.strip(), level=1)
        elif line.strip().startswith("【") and line.strip().endswith("】"):
            doc.add_heading(line.strip(), level=1)
        else:
            doc.add_paragraph(line.strip())

    # 保存文件
    os.makedirs("outputs", exist_ok=True)
    filename = f"outputs/{title}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx"
    doc.save(filename)
    return filename