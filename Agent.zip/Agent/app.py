from flask import Flask, request, make_response
from wechatpy.enterprise.crypto import WeChatCrypto
import xml.etree.ElementTree as ET
from agent import chat, clear_session
from wecom import send_message
from docx_gen import generate_docx

app = Flask(__name__)

CORP_ID = "XXX"
TOKEN = "XXX"
ENCODING_AES_KEY = "XXX"

crypto = WeChatCrypto(TOKEN, ENCODING_AES_KEY, CORP_ID)

@app.route("/")
def index():
    return "法律文书助手运行中"

@app.route("/webhook", methods=["GET", "POST"])
def webhook():
    if request.method == "GET":
        msg_signature = request.args.get("msg_signature", "")
        timestamp = request.args.get("timestamp", "")
        nonce = request.args.get("nonce", "")
        echostr = request.args.get("echostr", "")
        try:
            echostr = crypto.check_signature(msg_signature, timestamp, nonce, echostr)
            return make_response(echostr)
        except Exception as e:
            print(f"验证失败: {e}")
            return str(e), 403

    msg_signature = request.args.get("msg_signature", "")
    timestamp = request.args.get("timestamp", "")
    nonce = request.args.get("nonce", "")

    try:
        decrypted = crypto.decrypt_message(request.data, msg_signature, timestamp, nonce)
        xml_data = ET.fromstring(decrypted)
        print(f"收到消息: {ET.tostring(xml_data, encoding='unicode')}")
    except Exception as e:
        print(f"解密消息失败: {e}")
        return "ok"

    msg_type = xml_data.find("MsgType").text
    user_id = xml_data.find("FromUserName").text
    print(f"消息类型: {msg_type}, 用户ID: {user_id}")

    if msg_type != "text":
        send_message(user_id, "目前只支持文字消息，请发送文字。")
        return "ok"

    user_msg = xml_data.find("Content").text.strip()
    print(f"用户消息: {user_msg}")

    if user_msg in ["重置", "清空", "重新开始"]:
        reply = clear_session(user_id)
    else:
        reply = chat(user_id, user_msg)

    # 自动保存Word文档
    titles = {"意见书": "法律意见书", "备忘录": "法律备忘录", "诉讼": "诉讼方案"}
    doc_title = next((v for k, v in titles.items() if k in user_msg), None)
    if doc_title:
        filepath = generate_docx(doc_title, reply)
        print(f"文书已保存: {filepath}")

    print(f"回复内容: {reply[:50]}...")
    send_message(user_id, reply)
    return "ok"

if __name__ == "__main__":
    app.run(port=5000, debug=True)