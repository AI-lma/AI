import requests

CORP_ID = "XXX"
CORP_SECRET = "XXX"
AGENT_ID = XXX


def get_access_token():
    url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken"
    resp = requests.get(url, params={"corpid": CORP_ID, "corpsecret": CORP_SECRET})
    return resp.json()["access_token"]


def send_message(user_id, content):
    token = get_access_token()
    url = f"https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={token}"

    chunks = [content[i:i + 600] for i in range(0, len(content), 600)]

    for chunk in chunks:
        data = {
            "touser": user_id,
            "msgtype": "text",
            "agentid": AGENT_ID,
            "text": {"content": chunk}
        }
        requests.post(url, json=data)

    return {"errcode": 0, "errmsg": "ok"}