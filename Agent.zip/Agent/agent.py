from openai import OpenAI

DEEPSEEK_API_KEY = "XXX"

client = OpenAI(
    api_key=DEEPSEEK_API_KEY,
    base_url="https://api.deepseek.com"
)

SYSTEM_PROMPT = """你是一名专业的中国执业律师，擅长公司法、金融法、合同法及诉讼实务。
你的任务是帮助用户起草三类法律文书：法律意见书、法律备忘录、诉讼方案。

当用户发来请求时，你需要：
1. 判断用户需要哪类文书
2. 主动追问缺失的关键信息（委托方、法律问题、背景事实等）
3. 信息收集完整后，自动起草结构化文书

对话要简洁专业，像真实律师助手一样。"""

# 存储每个用户的对话历史
user_sessions = {}


def chat(user_id, user_message):
    if user_id not in user_sessions:
        user_sessions[user_id] = []

    user_sessions[user_id].append({
        "role": "user",
        "content": user_message
    })

    response = client.chat.completions.create(
        model="deepseek-chat",
        messages=[{"role": "system", "content": SYSTEM_PROMPT}] + user_sessions[user_id],
        max_tokens=2000
    )

    reply = response.choices[0].message.content

    user_sessions[user_id].append({
        "role": "assistant",
        "content": reply
    })

    return reply


def clear_session(user_id):
    if user_id in user_sessions:
        del user_sessions[user_id]
    return "对话已重置，请重新开始。"